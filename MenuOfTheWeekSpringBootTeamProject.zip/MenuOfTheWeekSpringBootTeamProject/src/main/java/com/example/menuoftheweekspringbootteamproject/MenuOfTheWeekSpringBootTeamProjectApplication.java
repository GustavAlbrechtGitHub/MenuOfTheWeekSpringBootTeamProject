package com.example.menuoftheweekspringbootteamproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenuOfTheWeekSpringBootTeamProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(MenuOfTheWeekSpringBootTeamProjectApplication.class, args);
    }

}
