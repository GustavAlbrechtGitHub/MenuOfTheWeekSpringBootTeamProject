package com.example.menuoftheweekspringbootteamproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenuOfTheWeekSpringBootTeamProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
